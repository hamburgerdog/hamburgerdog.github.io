const markdown = document.getElementById('markdown').textContent;
// node.js, "classic" way:
const md = window.markdownit({
	html: true,
	linkify: true,
	typographer: true,
});
md.use(window.markdownNamedHeadings);
md.use(window.markdownToc, { includeLevel: [1, 2, 3] });
const result = md.render(markdown);
document.getElementById('slot').innerHTML = result;

const theme = (() => {
	if (typeof localStorage !== 'undefined' && localStorage.getItem('theme')) {
		return localStorage.getItem('theme');
	}
	if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
		return 'dark';
	}
	return 'light';
})();

const btnID = 'modeBtn';
const btnElement = document.getElementById(btnID);

if (theme === 'light') {
	btnElement.setAttribute('src', './assets/sun.svg');
	document.documentElement.classList.remove('dark');
} else {
	btnElement.setAttribute('src', './assets/moon.svg');
	document.documentElement.classList.add('dark');
}

window.localStorage.setItem('theme', theme);

const handleToggleClick = (e) => {
	const src = e.target.src;
	const isMoon = src.endsWith('moon.svg');
	//	处理显示图标
	e.target.setAttribute('src', isMoon ? './assets/sun.svg' : './assets/moon.svg');
	//	更新css主题
	const element = document.documentElement;
	element.classList.toggle('dark');
	//	切换 localStorage 的存储变量
	const isDark = element.classList.contains('dark');
	localStorage.setItem('theme', isDark ? 'dark' : 'light');
};

document.getElementById('modeBtn').addEventListener('click', handleToggleClick);
